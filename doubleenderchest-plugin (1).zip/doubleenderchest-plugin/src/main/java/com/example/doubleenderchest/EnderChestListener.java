package com.example.doubleenderchest;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.block.data.BlockData;
import org.bukkit.block.data.Openable;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;

import java.io.File;
import java.io.IOException;
import java.util.UUID;

public class EnderChestListener implements Listener {

    private static final int SIZE = 54; // double chest size (vanilla ender chest is 27)

    private final DoubleEnderChestPlugin plugin;

    public EnderChestListener(DoubleEnderChestPlugin plugin) {
        this.plugin = plugin;
    }

    /** Marks our custom inventory so we know to save it (and animate/sound the right block) on close. */
    private static class DoubleEnderChestHolder implements InventoryHolder {
        final UUID ownerId;
        final Block block; // the specific ender chest block that was opened, for animation/sound
        private Inventory inventory;

        DoubleEnderChestHolder(UUID ownerId, Block block) {
            this.ownerId = ownerId;
            this.block = block;
        }

        void setInventory(Inventory inventory) {
            this.inventory = inventory;
        }

        @Override
        public Inventory getInventory() {
            return inventory;
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onInteract(PlayerInteractEvent event) {
        if (event.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        if (event.getClickedBlock() == null) return;
        if (event.getClickedBlock().getType() != Material.ENDER_CHEST) return;
        if (event.getHand() != org.bukkit.inventory.EquipmentSlot.HAND) return; // avoid firing twice (main + off hand)

        event.setCancelled(true); // stop the vanilla 27-slot ender chest from opening

        Player player = event.getPlayer();
        Block block = event.getClickedBlock();

        setOpen(block, true);
        block.getWorld().playSound(block.getLocation().add(0.5, 0.5, 0.5),
                Sound.BLOCK_ENDER_CHEST_OPEN, 0.5f, 1.0f);

        DoubleEnderChestHolder holder = new DoubleEnderChestHolder(player.getUniqueId(), block);
        Inventory inv = Bukkit.createInventory(holder, SIZE, "Ender Chest");
        holder.setInventory(inv);
        inv.setContents(loadContents(player));
        player.openInventory(inv);
    }

    @EventHandler
    public void onClose(InventoryCloseEvent event) {
        if (!(event.getInventory().getHolder() instanceof DoubleEnderChestHolder holder)) return;
        if (!(event.getPlayer() instanceof Player player)) return;

        saveContents(player, event.getInventory().getContents());

        if (holder.block != null && holder.block.getType() == Material.ENDER_CHEST) {
            setOpen(holder.block, false);
            holder.block.getWorld().playSound(holder.block.getLocation().add(0.5, 0.5, 0.5),
                    Sound.BLOCK_ENDER_CHEST_CLOSE, 0.5f, 1.0f);
        }
    }

    private void setOpen(Block block, boolean open) {
        BlockData data = block.getBlockData();
        if (data instanceof Openable openable) {
            openable.setOpen(open);
            block.setBlockData(data);
        }
    }

    // ---------------------------------------------------------------
    // Storage: one small YAML file per player under plugins/DoubleEnderChest/enderchests/
    // ---------------------------------------------------------------

    private File getPlayerFile(Player player) {
        File dir = new File(plugin.getDataFolder(), "enderchests");
        if (!dir.exists()) dir.mkdirs();
        return new File(dir, player.getUniqueId() + ".yml");
    }

    private ItemStack[] loadContents(Player player) {
        ItemStack[] contents = new ItemStack[SIZE];
        File file = getPlayerFile(player);
        if (!file.exists()) return contents;

        YamlConfiguration yaml = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection section = yaml.getConfigurationSection("items");
        if (section != null) {
            for (String key : section.getKeys(false)) {
                try {
                    int slot = Integer.parseInt(key);
                    if (slot >= 0 && slot < SIZE) {
                        contents[slot] = section.getItemStack(key);
                    }
                } catch (NumberFormatException ignored) {
                    // skip malformed keys
                }
            }
        }
        return contents;
    }

    private void saveContents(Player player, ItemStack[] contents) {
        YamlConfiguration yaml = new YamlConfiguration();
        for (int i = 0; i < contents.length; i++) {
            if (contents[i] != null) {
                yaml.set("items." + i, contents[i]);
            }
        }
        try {
            yaml.save(getPlayerFile(player));
        } catch (IOException e) {
            plugin.getLogger().warning("Failed to save double ender chest for " + player.getName() + ": " + e.getMessage());
        }
    }
}
