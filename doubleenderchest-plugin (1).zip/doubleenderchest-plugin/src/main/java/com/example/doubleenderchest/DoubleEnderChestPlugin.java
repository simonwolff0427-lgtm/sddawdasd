package com.example.doubleenderchest;

import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;

public final class DoubleEnderChestPlugin extends JavaPlugin {

    @Override
    public void onEnable() {
        Bukkit.getPluginManager().registerEvents(new EnderChestListener(this), this);
        getLogger().info("DoubleEnderChest enabled — ender chests are now 54 slots instead of 27.");
    }
}
