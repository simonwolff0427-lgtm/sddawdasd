# DoubleEnderChest

Doubles the size of every player's ender chest — 54 slots instead of the
vanilla 27 (same size as a double chest).

## How it works

Minecraft hardcodes the real ender chest to 27 slots; there's no vanilla way
to resize it directly. So this plugin intercepts the moment a player opens an
ender chest, cancels the vanilla one, and shows a custom 54-slot inventory
instead. Contents are saved to a small file per player under
`plugins/DoubleEnderChest/enderchests/<uuid>.yml` when they close it, and
loaded back the next time they open it.

No commands, no permissions, no config — it just works automatically for
every player the moment it's installed.

## Note

This is a separate storage space from the vanilla ender chest, not a resize
of it — if players had items in their vanilla ender chest before installing
this, those items are safe (Minecraft still has them) but won't show up here;
they'd need to be moved over manually, or you'd install this before your
players start filling their ender chests.

## Building

Same as the other plugins: upload this whole folder as a zip to a GitHub
repo, add `.github/workflows/build.yml` (already included here), and GitHub
Actions builds `DoubleEnderChest-1.0.0.jar` — download it from the Actions
tab's Artifacts section once green.
